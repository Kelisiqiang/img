// Saves options to chrome.storage
const saveOptions = () => {
  const notionApiKey = document.getElementById('notion-api-key').value;
  const notionDatabaseId = document.getElementById('notion-database-id').value;

  chrome.storage.sync.set(
    { notionApiKey, notionDatabaseId },
    () => {
      // Show status message
      const status = document.getElementById('status');
      status.textContent = 'Configuration saved successfully!';
      status.className = 'block text-sm font-medium text-green-400 bg-green-900/30 border border-green-800 p-2 rounded-md';
      
      // Hide status message after 3 seconds
      setTimeout(() => {
        status.className = 'hidden';
      }, 3000);
    }
  );
};

// Restores select box and checkbox state using the preferences
// stored in chrome.storage.
const restoreOptions = () => {
  chrome.storage.sync.get(
    { notionApiKey: '', notionDatabaseId: '' },
    (items) => {
      document.getElementById('notion-api-key').value = items.notionApiKey;
      document.getElementById('notion-database-id').value = items.notionDatabaseId;
    }
  );
};

document.addEventListener('DOMContentLoaded', restoreOptions);
document.getElementById('save-options').addEventListener('click', saveOptions);
