// Listen for messages from popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'fetchBookmarks') {
    const bookmarks = extractBookmarks();
    sendResponse({ bookmarks });
  }
});

// Extract bookmarks from the page
const extractBookmarks = () => {
  const bookmarks = [];
  
  // Select all tweet elements
  const tweetElements = document.querySelectorAll('[data-testid="tweet"]');
  
  tweetElements.forEach((tweetElement) => {
    try {
      // Extract author name
      const authorElement = tweetElement.querySelector('[data-testid="User-Name"] span');
      const author = authorElement ? authorElement.textContent : '';
      
      // Extract author handle
      const handleElement = tweetElement.querySelector('[data-testid="User-Name"] a');
      const authorHandle = handleElement ? handleElement.getAttribute('href').replace('/', '') : '';
      
      // Extract content
      const contentElement = tweetElement.querySelector('[data-testid="tweetText"]');
      const content = contentElement ? contentElement.textContent : '';
      
      // Extract timestamp
      const timestampElement = tweetElement.querySelector('time');
      const timestamp = timestampElement ? new Date(timestampElement.getAttribute('datetime')).toISOString() : '';
      
      // Extract tweet URL
      const tweetLinkElement = tweetElement.querySelector('[data-testid="tweetText"] a[href^="/"]');
      let tweetUrl = '';
      
      if (tweetLinkElement) {
        const path = tweetLinkElement.getAttribute('href');
        if (path.includes('/status/')) {
          tweetUrl = `https://x.com${path.split('?')[0]}`;
        }
      }
      
      // Only add valid bookmarks
      if (author && content && timestamp && tweetUrl) {
        bookmarks.push({
          author,
          authorHandle,
          content,
          timestamp,
          url: tweetUrl
        });
      }
    } catch (error) {
      console.error('Error extracting tweet data:', error);
    }
  });
  
  return bookmarks;
};
