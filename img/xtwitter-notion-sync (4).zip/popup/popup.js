// Check if user is on X bookmarks page
const checkIfOnBookmarksPage = () => {
  return new Promise((resolve) => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const url = tabs[0].url;
      resolve(url && url.includes('x.com') && url.includes('/bookmarks'));
    });
  });
};

// Check if Notion is configured
const checkNotionConfiguration = () => {
  return new Promise((resolve) => {
    chrome.storage.sync.get(['notionApiKey', 'notionDatabaseId'], (items) => {
      resolve(!!items.notionApiKey && !!items.notionDatabaseId);
    });
  });
};

// Show status message
const showStatus = (message, isError = false) => {
  const statusElement = document.getElementById('status');
  statusElement.textContent = message;
  statusElement.className = `mb-4 p-2 rounded-md text-center text-sm font-medium ${
    isError ? 'bg-red-900/30 text-red-400 border border-red-800' : 'bg-green-900/30 text-green-400 border border-green-800'
  }`;
  statusElement.classList.remove('hidden');
  
  // Hide after 5 seconds
  setTimeout(() => {
    statusElement.classList.add('hidden');
  }, 5000);
};

// Fetch bookmarks from content script
const fetchBookmarks = () => {
  return new Promise((resolve) => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      chrome.tabs.sendMessage(tabs[0].id, { action: 'fetchBookmarks' }, (response) => {
        resolve(response?.bookmarks || []);
      });
    });
  });
};

// Sync bookmarks to Notion
const syncToNotion = (bookmarks) => {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage({ action: 'syncToNotion', bookmarks }, (response) => {
      resolve(response);
    });
  });
};

// Render bookmarks preview
const renderBookmarksPreview = (bookmarks) => {
  const bookmarksList = document.getElementById('bookmarks-list');
  bookmarksList.innerHTML = '';
  
  if (bookmarks.length === 0) {
    bookmarksList.innerHTML = '<p class="text-sm text-gray-500 text-center py-4">No bookmarks found.</p>';
    return;
  }
  
  bookmarks.forEach((bookmark) => {
    const tweetCard = document.createElement('div');
    tweetCard.className = 'tweet-card';
    
    tweetCard.innerHTML = `
      <div class="flex items-start gap-2">
        <div class="w-8 h-8 rounded-full bg-gray-200 flex-shrink-0"></div>
        <div class="flex-1 min-w-0">
          <div class="flex items-center gap-1">
            <span class="font-medium text-gray-800 text-sm">${bookmark.author}</span>
            <span class="text-gray-400 text-xs">@${bookmark.authorHandle}</span>
          </div>
          <p class="text-sm text-gray-600 mt-1 line-clamp-2">${bookmark.content}</p>
          <div class="flex items-center gap-4 mt-2 text-xs text-gray-400">
            <span>${new Date(bookmark.timestamp).toLocaleDateString()}</span>
            <span><i class="fa fa-link"></i></span>
          </div>
        </div>
      </div>
    `;
    
    bookmarksList.appendChild(tweetCard);
  });
  
  document.getElementById('bookmarks-container').classList.remove('hidden');
};

// Initialize popup
document.addEventListener('DOMContentLoaded', async () => {
  const isOnBookmarksPage = await checkIfOnBookmarksPage();
  const isNotionConfigured = await checkNotionConfiguration();
  
  const mainContent = document.getElementById('main-content');
  const notConfigured = document.getElementById('not-configured');
  
  if (!isOnBookmarksPage) {
    mainContent.innerHTML = `
      <div class="card text-center py-6">
        <i class="fa fa-info-circle text-blue-500 text-2xl mb-3"></i>
        <h2 class="text-md font-semibold text-gray-700 mb-2">Not on Bookmarks Page</h2>
        <p class="text-sm text-gray-500">Please navigate to your X bookmarks page to use this extension.</p>
      </div>
    `;
  } else if (!isNotionConfigured) {
    mainContent.classList.add('hidden');
    notConfigured.classList.remove('hidden');
  }
  
  // Open options page
  document.getElementById('open-options').addEventListener('click', () => {
    chrome.runtime.openOptionsPage();
  });
  
  // Fetch bookmarks button
  document.getElementById('fetch-button').addEventListener('click', async () => {
    showStatus('Fetching bookmarks...');
    
    try {
      const bookmarks = await fetchBookmarks();
      renderBookmarksPreview(bookmarks);
      showStatus(`Fetched ${bookmarks.length} bookmarks`);
    } catch (error) {
      showStatus('Failed to fetch bookmarks', true);
      console.error(error);
    }
  });
  
  // Sync to Notion button
  document.getElementById('sync-button').addEventListener('click', async () => {
    showStatus('Syncing to Notion...');
    
    try {
      const bookmarks = await fetchBookmarks();
      const result = await syncToNotion(bookmarks);
      
      if (result.success) {
        showStatus(`Successfully synced ${result.syncedCount} bookmarks to Notion`);
      } else {
        showStatus(result.message || 'Failed to sync to Notion', true);
      }
    } catch (error) {
      showStatus('Failed to sync to Notion', true);
      console.error(error);
    }
  });
});
