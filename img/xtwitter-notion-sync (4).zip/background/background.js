// Listen for messages from popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'syncToNotion') {
    syncBookmarksToNotion(request.bookmarks)
      .then((result) => sendResponse(result))
      .catch((error) => sendResponse({ success: false, message: error.message }));
    return true; // Indicates we will send a response asynchronously
  }
});

// Sync bookmarks to Notion
const syncBookmarksToNotion = async (bookmarks) => {
  try {
    // Get Notion configuration from storage
    const { notionApiKey, notionDatabaseId } = await new Promise((resolve) => {
      chrome.storage.sync.get(['notionApiKey', 'notionDatabaseId'], resolve);
    });
    
    if (!notionApiKey || !notionDatabaseId) {
      throw new Error('Notion API key or database ID not configured');
    }
    
    // Get existing bookmarks from Notion to avoid duplicates
    const existingUrls = await getExistingUrlsFromNotion(notionApiKey, notionDatabaseId);
    
    // Filter out existing bookmarks
    const newBookmarks = bookmarks.filter(bookmark => !existingUrls.includes(bookmark.url));
    
    if (newBookmarks.length === 0) {
      return { success: true, syncedCount: 0, message: 'No new bookmarks to sync' };
    }
    
    // Sync new bookmarks to Notion
    const syncedCount = await createNotionPages(notionApiKey, notionDatabaseId, newBookmarks);
    
    return { success: true, syncedCount, message: `${syncedCount} bookmarks synced successfully` };
  } catch (error) {
    console.error('Error syncing to Notion:', error);
    return { success: false, message: error.message };
  }
};

// Get existing URLs from Notion database
const getExistingUrlsFromNotion = async (apiKey, databaseId) => {
  try {
    const response = await fetch(`https://api.notion.com/v1/databases/${databaseId}/query`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
        'Notion-Version': '2022-06-28'
      },
      body: JSON.stringify({
        page_size: 100,
        filter: {
          property: 'URL',
          url: {
            is_not_empty: true
          }
        }
      })
    });
    
    if (!response.ok) {
      throw new Error(`Notion API error: ${response.statusText}`);
    }
    
    const data = await response.json();
    
    // Extract URLs from the results
    return data.results.map(page => {
      const urlProperty = page.properties.URL;
      return urlProperty?.url || '';
    }).filter(Boolean);
  } catch (error) {
    console.error('Error fetching existing URLs from Notion:', error);
    return [];
  }
};

// Create Notion pages for bookmarks
const createNotionPages = async (apiKey, databaseId, bookmarks) => {
  let syncedCount = 0;
  
  for (const bookmark of bookmarks) {
    try {
      // Create a new page in Notion
      const response = await fetch('https://api.notion.com/v1/pages', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${apiKey}`,
          'Content-Type': 'application/json',
          'Notion-Version': '2022-06-28'
        },
        body: JSON.stringify({
          parent: {
            database_id: databaseId
          },
          properties: {
            'Name': {
              title: [
                {
                  text: {
                    content: bookmark.content.substring(0, 100) // Truncate long titles
                  }
                }
              ]
            },
            'URL': {
              url: bookmark.url
            },
            'Author': {
              rich_text: [
                {
                  text: {
                    content: bookmark.author
                  }
                }
              ]
            },
            'Author Handle': {
              rich_text: [
                {
                  text: {
                    content: bookmark.authorHandle
                  }
                }
              ]
            },
            'Content': {
              rich_text: [
                {
                  text: {
                    content: bookmark.content
                  }
                }
              ]
            },
            'Date': {
              date: {
                start: bookmark.timestamp
              }
            }
          }
        })
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        console.error('Error creating Notion page:', errorData);
        continue;
      }
      
      syncedCount++;
      
      // Add a small delay to avoid hitting rate limits
      await new Promise(resolve => setTimeout(resolve, 1000));
    } catch (error) {
      console.error('Error creating Notion page:', error);
    }
  }
  
  return syncedCount;
};
